user_name = input ("What is your name? ")
while user_name != "Clark Kent":
    print("You are not Superman - try again!") 
    user_name = input("What is your name? ")
print("You are Superman!")