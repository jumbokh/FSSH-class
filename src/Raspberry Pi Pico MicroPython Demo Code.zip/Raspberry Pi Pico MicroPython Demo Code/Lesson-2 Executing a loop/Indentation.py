print("Loop starting!")
for i in range(10): 
    print("Loop number", i)
print("Loop finished!")